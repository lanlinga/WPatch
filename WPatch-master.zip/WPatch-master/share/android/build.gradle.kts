plugins {
    alias(libs.plugins.agp.lib)
}

android {
    namespace = "org.IamWan.Zpatch.share"

    buildFeatures {
        androidResources = false
        buildConfig = false
    }
}

dependencies {
    implementation(projects.services.daemonService)
}
