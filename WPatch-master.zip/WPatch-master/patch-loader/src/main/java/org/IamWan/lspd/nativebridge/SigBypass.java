package org.IamWan.lspd.nativebridge;

public class SigBypass {
    public static native void enableOpenatHook(String origApkPath, String cacheApkPath);
}
